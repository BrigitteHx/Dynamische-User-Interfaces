// M01.O4 - Horeca App

var bier = 0;
var wijn = 0;
var fris = 0; 

var input; 

function bestelling(){
    while (input != "stop"){
        input = prompt("Wat wilt u drinken? Kies uit 'bier, wijn, fris'.")

    if (input == "bier"){
        var bierTotaal = prompt("Hoeveel bier wilt u bestellen?");
        bier += bierTotaal;
        // console.log(bier, "x", bierPrijs);
    }

    else if (input == "wijn"){
        var wijnTotaal = prompt("Hoeveel wijn wilt u bestellen?");
        wijn += wijnTotaal;
        // console.log(wijn, "x", wijnPrijs);
    }

    else if (input == "fris"){
        var frisTotaal = prompt("Hoeveel fris wilt u bestellen?");
        fris += frisTotaal;
        // console.log(fris, "x", frisPrijs);
    }
}
}

bestelling();

// ---------------------------------------------------------------------------------------------------------------

// prijzen:
const bierPrijs = 5;
const wijnPrijs = 6;
const frisPrijs = 3;

function prijsBerekenen(){

    var totaalBierPrijs = bier * bierPrijs;
    var totaalWijnPrijs = wijn * wijnPrijs;
    var totaalFrisPrijs = fris * frisPrijs;
    var totaal = totaalBierPrijs+totaalWijnPrijs+totaalFrisPrijs;

    if (bier > 0){
        document.write("U heeft", bier, "bier.", "Voor", totaalBierPrijs);
		document.write("<br><br>");	
    }

    if (wijn > 0){
        document.write("U heeft", wijn, "wijn.", "Voor", totaalWijnPrijs);
		document.write("<br><br>");	
    }

    if (fris > 0){
        document.write("U heeft", fris, "fris.", "Voor", totaalFrisPrijs);
		document.write("<br><br>");	
    }

    document.write("De totale prijs is", totaal)
}

prijsBerekenen(); 